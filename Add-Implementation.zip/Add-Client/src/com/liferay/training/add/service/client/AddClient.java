package com.liferay.training.add.service.client;

import com.liferay.training.add.service.AddService;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.osgi.service.component.annotations.ReferencePolicy;

@Component(
		immediate =  true,
		property = {
				"osgi.command.function=add",
				"osgi.command.scope=custom"
		},
		service = Object.class
		)
public class AddClient {

	private AddService addService;
	
	  public void add(int a, int b) {
	        System.out.println(addService.add(a, b));
	    }
		
		@Reference(
			policy = ReferencePolicy.DYNAMIC,
			cardinality = ReferenceCardinality.OPTIONAL
		)

		public void setAddService(AddService addService) {
			System.out.println("setting up Add service for adding of numbers.");
			this.addService = addService;
		}
		
		public void unsetAddService(AddService addService) {
		System.out.println("client implementation removed or updated");
		this.addService = null;
		}
		
		@Activate
		public void testmodule() {
			if(addService != null) {
				System.out.println("Add service is ready for adding numbers...");
			}
			else
			{
				System.out.println("No service is availabeon this name.");
			
			}	
	}
}
