package com.liferay.training.add.service;

public interface AddService {

	public int add(int a, int b);
}
