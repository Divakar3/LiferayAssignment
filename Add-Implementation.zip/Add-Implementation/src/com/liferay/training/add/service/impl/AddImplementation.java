package com.liferay.training.add.service.impl;

import com.liferay.training.add.service.AddService;
import org.osgi.service.component.annotations.Component;

@Component(immediate = true, properties = {}, service = AddService.class)
public class AddImplementation implements AddService{
	
	@Override
	public int add(int a, int b) {
		System.out.println("Addition Method invoke....");
		int result = a + b;
		System.out.println("Add "+ a +" , "+ b +" is "+result);
		return result;
	}

}
